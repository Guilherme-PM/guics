export const environment = {
    production: false,
    urlSite: 'http://localhost:4200/',
    apiUrl: 'http://localhost:5000/api'
}