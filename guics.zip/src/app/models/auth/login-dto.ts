export class LoginDTO {
  email!: string;
  password!: string;
}
