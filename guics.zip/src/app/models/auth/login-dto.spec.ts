import { LoginDTO } from './login-dto';

describe('LoginDTO', () => {
  it('should create an instance', () => {
    expect(new LoginDTO()).toBeTruthy();
  });
});
